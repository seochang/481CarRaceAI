﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class AiCar3: MonoBehaviour {

	public GameObject[] waypoints;
	public GameObject startNode;
	//public GameObject goalNode;
	public GameObject goalNode;
	List<GameObject> tempPath;
	GameObject[]path;
	int currentNode;
	int count;
	public float speed;
	float dist;


	// Use this for initialization
	void Start () {
		currentNode = 0;
		count = waypoints.Length;

		tempPath = new List<GameObject> ();
		FindPath (waypoints, tempPath);
		count = tempPath.Count;
		path = new GameObject[count];

		for(int n = 0; n < count; n++) {
			path [n] = tempPath [n];
		}



	}

	// Update is called once per frame
	void Update () {
		if (transform.position != path [currentNode].transform.position) {
			Vector3 pos = Vector3.MoveTowards (transform.position, path[currentNode].transform.position, speed * Time.deltaTime);
			GetComponent<Rigidbody2D> ().MovePosition (pos);
			//transform.LookAt(path[currentNode].transform);
			LookAt2D (transform, path [currentNode]);
		} else
			currentNode = (currentNode + 1) % path.Length;
	}


	void FindPath(GameObject[] waypoints,List<GameObject>path){
		List<GameObject> OpenSet;
		List<GameObject> ClosedSet;

		GameObject parent = null;

		bool finished = false; 

		OpenSet = new List<GameObject>(waypoints);
		ClosedSet = new List<GameObject>();
		ClosedSet.Add (startNode);
		parent = startNode;

		if (parent == goalNode) {
			finished = true;
		}
		while (finished == false) {
			if (parent == goalNode) {
				finished = true;
			}
			if (OpenSet.Count < 2) {
				parent = goalNode;
			}
			else if (f_cost (parent, OpenSet [0], goalNode) > (f_cost (parent, OpenSet [1], goalNode))) {
				parent = OpenSet [1];
			} else {
				parent = OpenSet [0];
			}
			ClosedSet.Add(parent);
			OpenSet.Remove(parent);
		}

		Done (ClosedSet, path);
	}

	float g_cost(GameObject curNode, GameObject nextNode){
		dist = Vector2.Distance (curNode.transform.position, nextNode.transform.position);
		return dist;
	}

	float h_cost(GameObject curNode, GameObject goalNode){
		dist = Vector2.Distance (curNode.transform.position, goalNode.transform.position);
		return dist;
	}

	float f_cost(GameObject curNode, GameObject nextNode, GameObject goalNode ){
		dist = g_cost (curNode, nextNode) + h_cost (nextNode, goalNode);
		return dist;
	}

	void Done(List<GameObject> ClosedSet,List<GameObject> path){

		int c = ClosedSet.Count;
		for (int i = 0; i < c; i++) {

			path.Add(ClosedSet [i]);
		}

	}

	public static void LookAt2D(Transform transform, GameObject target)
	{
		Vector3 current = transform.position;
		var direction = target.transform.position - current;
		var angle = Mathf.Atan2(direction.y, direction.x)*Mathf.Rad2Deg + 270;
		transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
	}
}