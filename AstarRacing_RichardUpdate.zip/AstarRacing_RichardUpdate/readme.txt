AI Racers instructions

If not already installed, download and install Unity engine
Open up unity and select open project
navigate to the AI Racers Folder
select it
underneath the "project" tab, open up the main menu scene in the Scene folder
hit the play button at the top of the screen
move with arrow keys.