﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour {

    // Use this for initialization
    void Start() {

    }

    // Update is called once per frame
    void Update() {

    }
    public void LoadTrack1()
    {

    }
    public void LoadTrack2()
    {
        SceneManager.LoadScene("Astarworking");
    }
    public void LoadTrack3()
    {
        
    }
    public void Exit()
    {
        Application.Quit();
    }
    
}
