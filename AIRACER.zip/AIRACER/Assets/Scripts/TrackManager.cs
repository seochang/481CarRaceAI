﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TrackManager : MonoBehaviour {
    //public List<GameObject> NodeList;
    float raceTime=0;
    int lap=1;
    bool raceFinished = false;
    public int totalLaps = 3;//the total number of laps we will have in this race. defaults to 3
    public GameObject finishLine; //the finish line for the race. 
    public GameObject gui;
    Text lapText;
    Text timer;
    Text winner;
    GameObject winningCar;
    public GameObject[] checkPoints;    //the checkpoints to ensure that the cars have gone around the track. each car will need to keep track of 
                                        //and report their checkpoints            
	// Use this for initialization
	void Start ()
    {
        gui = GameObject.Find("GUI");
        lapText = GameObject.Find("lap").GetComponent<Text>();
        timer = GameObject.Find("timer").GetComponent<Text>();
        winner = GameObject.Find("winner").GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        //update race timer
        if (!raceFinished)
        {
            raceTime += Time.deltaTime;
            timer.text = "Race Time: " + raceTime.ToString("F2");
        }
        if (raceFinished)//congratulate winner
        {
            winner.text = winningCar.name + " has won in " + raceTime.ToString("F2") + " secconds";
            winner.gameObject.transform.localScale = new Vector3(1, 1, 1);// set visibility of winner text
        }

    }
   public void NextLap(int nLap,GameObject car)//maintain lap counter, car passes lap it is starting. If car lap exceeds track lap, increment track lap
    {
        if (!raceFinished)
        {
            if(nLap>lap)
            {
                lap += 1;
            }
            if (lap > totalLaps)
            {
                winningCar = car;
                raceFinished = true;
                lap = totalLaps;
            }
            lapText.text = "Lap: " + lap + "/" + totalLaps;
        }
    }
}
