﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class NodeDrive : MonoBehaviour {

	public GameObject[] waypoints; 
	public GameObject startNode;
	public GameObject goalNode;
	GameObject[] path;
	int currentNode;
	int count1;
	public float speed;
	float dist;


	// Use this for initialization
	void Start () {
		currentNode = 0;
		count1 = waypoints.Length;
		path = new GameObject [count1];
		FindPath (waypoints, path);

		/*for (int i =0 ; i< count1;i++){

			path[i] = waypoints[i];
		}
*/
	}

	// Update is called once per frame
	void Update () {
		if (transform.position != path [currentNode].transform.position) {
			Vector3 pos = Vector3.MoveTowards (transform.position, path[currentNode].transform.position, speed * Time.deltaTime);
			GetComponent<Rigidbody2D> ().MovePosition (pos);
			LookAt2D (transform, path [currentNode]);
		} else
			currentNode = (currentNode + 1) % path.Length;
	}


	void FindPath(GameObject[] waypoints,GameObject[] path){
		List<GameObject> OpenSet;
		List<GameObject> ClosedSet;
		List<GameObject> adjacent;
		adjacent = new List<GameObject> ();

		GameObject curNode = null;
		GameObject parent = null;

		bool finished = false; //done

		OpenSet = new List<GameObject>(waypoints);

		ClosedSet = new List<GameObject>();

		ClosedSet.Add (OpenSet [0]);
		OpenSet.Remove (OpenSet [0]);
		parent = OpenSet [0];


		set_openset (OpenSet, startNode);

		GetPath (OpenSet, ClosedSet, adjacent, startNode, goalNode, curNode, parent, finished);

		Done (ClosedSet, path);





	}


	void GetPath(List<GameObject> OpenSet,List<GameObject> ClosedSet, List<GameObject> adjacent,GameObject startNode, GameObject goalNode, GameObject curNode,GameObject parent, bool finished)
	{
		curNode = OpenSet [0];
		while(finished == false){
			if (parent == goalNode) {
				ClosedSet.Add (parent);
				finished = true;
			}
			if (finished == true) {
				return;
			}else{
				FindCurNode (parent, startNode, goalNode, curNode, adjacent, OpenSet);
				while(g_cost(startNode, curNode) == g_cost(parent, curNode)){
					if((g_cost(startNode, curNode) + h_cost(curNode, goalNode)) < (g_cost(startNode, parent, curNode) + h_cost(curNode, goalNode))){
						adjacent.Remove(curNode);
						FindCurNode (parent, startNode, goalNode, curNode, adjacent, OpenSet);
					}
				}//if the neighbor is also adjacent to the startNode, check which is better
				ClosedSet.Add(parent);
				OpenSet.Remove (parent);
				parent = curNode;
			}
		}	
	}

	void Adjacent(GameObject parent, List<GameObject> adjacent, List<GameObject> OpenSet){
		adjacent = new List<GameObject> ();
		for (int k = 0; k < OpenSet.Count; k++) {
			adjacent.Add (OpenSet[k]);
		}
		GameObject cand;
		adjacent.Remove (parent);
		for (int i = 0; i < adjacent.Count; i++) {
			for (int j = 0; j < adjacent.Count - 1; j++) {
				if (g_cost (parent, adjacent [j]) > g_cost (parent, adjacent [j + 1])) {
					cand = adjacent [j];
					adjacent [j] = adjacent [j + 1];
					adjacent [j + 1] = cand;
				}
			}
		}
	}

	void FindCurNode(GameObject parent, GameObject startNode, GameObject goalNode, GameObject curNode, List<GameObject> adjacent, List<GameObject> OpenSet ){

		for (int i = 0; i < adjacent.Count; i++) {
			if ((g_cost (startNode, parent, curNode) + h_cost (curNode, goalNode)) > (g_cost (startNode, parent, adjacent [i]) + h_cost (adjacent [i], goalNode))) {
				curNode = adjacent [i];
			}
		}//find smallest f_cost of neighbor

		//curNode = n;

	}
	float g_cost(GameObject startNode, GameObject parent, GameObject curNode){
		dist = Vector3.Distance (startNode.transform.position, parent.transform.position) + Vector3.Distance (parent.transform.position, curNode.transform.position);
		return dist;
	}


	float g_cost(GameObject startNode, GameObject curNode){
		dist = Vector3.Distance (startNode.transform.position, curNode.transform.position);
		return dist;
	}

	float h_cost(GameObject curNode, GameObject goalNode){
		dist = Vector3.Distance (curNode.transform.position, goalNode.transform.position);
		return dist;
	}

	float f_score(GameObject startNode, GameObject goalNode, GameObject curNode){
		dist = g_cost (startNode, curNode) + h_cost (curNode, goalNode);
		return dist;
	}

	void set_openset(List<GameObject> OpenSet, GameObject startNode){
		GameObject temp;
		for (int i = 0; i < OpenSet.Count; i++) {
			for (int j = 0; j < OpenSet.Count - 1; j++) {
				if (g_cost(startNode, OpenSet[j]) > g_cost(startNode, OpenSet[j+1])){
					temp = OpenSet [j];
					OpenSet [j] = OpenSet [j + 1];
					OpenSet [j + 1] = temp;
				}
			}
		}
	}


	void Done(List<GameObject> ClosedSet, GameObject[] path){

		for (int i = 0; i < ClosedSet.Count; i++) {

			path [i] = ClosedSet [i];
		}

	}

	public static void LookAt2D(Transform transform, GameObject target)
	{
		Vector3 current = transform.position;
		var direction = target.transform.position - current;
		var angle = Mathf.Atan2(direction.y, direction.x)*Mathf.Rad2Deg + 270;
		transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
	}
}