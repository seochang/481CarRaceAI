﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class temp1: MonoBehaviour {

	public GameObject[] waypoint1; 
	public GameObject[] waypoint2; 
	public GameObject goalNode;
	public GameObject midNode;
	GameObject[] path;
	int currentNode;
	int count1;
	int count2;
	int mid;
	public float speed;
	float dist;


	// Use this for initialization
	void Start () {
		currentNode = 0;
		//count1 = waypoint1.Length;
		count2 = waypoint2.Length;
		List<GameObject> temp;
		temp = new List<GameObject>(waypoint1);
		/*for (int i = 0; i < count2; i++) {
			temp.Add(waypoint2[i]);
		}

		int count = temp.Count;
		path = new GameObject [count];
		for (int k = 0; k < count; k++) {
			path [k] = temp [k];
		}

		count = waypoints.Length;

		mid = count % 2;
		FindPath (waypoints, path);


	}

	// Update is called once per frame
	void Update () {
		if (transform.position != path [currentNode].transform.position) {
			Vector3 pos = Vector3.MoveTowards (transform.position, path[currentNode].transform.position, speed * Time.deltaTime);
			GetComponent<Rigidbody2D> ().MovePosition (pos);
			//transform.LookAt(path[currentNode].transform);
			LookAt2D (transform, path [currentNode]);
		} else
			currentNode = (currentNode + 1) % path.Length;
	}


	void FindPath(GameObject[] waypoints,GameObject[] path){
		List<GameObject> OpenSet;
		List<GameObject> ClosedSet;
		List<GameObject> adjacent;
		adjacent = new List<GameObject> ();

		GameObject startNode = null;
		GameObject parent = null;

		bool finished = false; 

		OpenSet = new List<GameObject>(waypoints);
		midNode = OpenSet[mid];
		ClosedSet = new List<GameObject>();
		startNode = OpenSet[0];
		ClosedSet.Add (OpenSet [0]);
		OpenSet.Remove (OpenSet [0]);
		parent = OpenSet [0];


		GetPath (OpenSet, ClosedSet, adjacent, startNode, goalNode, parent, finished);

		Done (ClosedSet, path);





	}


	void GetPath(List<GameObject> OpenSet,List<GameObject> ClosedSet, List<GameObject> adjacent,GameObject startNode, GameObject goalNode, GameObject parent, bool finished)
	{
		int cur = 0;
		if (OpenSet.Count == 0) {
			return;

		}
		while(finished == false){
			if (parent == goalNode) {
				ClosedSet.Add (parent);
				finished = true;
			}
			if (finished == true) {
				return;
			}else{
				if (parent != midNode) {
					FindnextNode (parent, cur, OpenSet, ClosedSet);
				} else  {
					Adjacent (parent, cur, OpenSet, ClosedSet);
				} 
				ClosedSet.Add(parent);
				OpenSet.Remove (parent);
			}
		}	
	}


	void FindnextNode(GameObject parent, int cur, List<GameObject> OpenSet, List<GameObject> ClosedSet ){
		int n;
		n = cur;
		int Nodenum = 0;
		GameObject temp = OpenSet [0];
		if (OpenSet.Count == 2) {
			ClosedSet.Add (OpenSet [0]);
			ClosedSet.Add (OpenSet [1]);
			OpenSet.Remove(OpenSet [0]);
			OpenSet.Remove (OpenSet [1]);
			parent = midNode;
			cur = 0;

		}else{
			for (int i = 0; i < mid - n + 1; i++) {
				if(f_cost(parent, temp, midNode) > f_cost(parent, OpenSet[i], midNode)){
					Nodenum = n;
					temp = OpenSet[i];
				}
				n++;
			}
			parent = temp;
			cur = Nodenum;
			reset (OpenSet, cur);
		}
	}

	void Adjacent(GameObject parent, int cur, List<GameObject> OpenSet, List<GameObject> ClosedSet){
		int n;
		n = cur;
		int Nodenum = 0;
		GameObject temp = OpenSet [0];
		if (OpenSet.Count == 2) {
			ClosedSet.Add (OpenSet [0]);
			ClosedSet.Add (OpenSet [1]);
			OpenSet.Remove(OpenSet [0]);
			OpenSet.Remove(OpenSet [1]);
			parent = goalNode;

		}else{
			for (int i = 0; i < mid - n + 1; i++) {
				if(f_cost(parent, temp, goalNode) > f_cost(parent, OpenSet[i], goalNode)){
					Nodenum = n;
					temp = OpenSet[i];
				}
				n++;
			}
			parent = temp;
			cur = Nodenum;
			reset (OpenSet, cur);
		}
	}


	void reset(List<GameObject> OpenSet, int cur){
		for(int k = 0; k < cur; k++){
			OpenSet.Remove (OpenSet [k]);
		}
	}
	float g_cost(GameObject curNode, GameObject nextNode){
		dist = Vector2.Distance (curNode.transform.position, nextNode.transform.position);
		return dist;
	}

	float h_cost(GameObject curNode, GameObject goalNode){
		dist = Vector2.Distance (curNode.transform.position, goalNode.transform.position);
		return dist;
	}

	float f_cost(GameObject curNode, GameObject nextNode, GameObject goalNode ){
		dist = g_cost (curNode, nextNode) + h_cost (nextNode, goalNode);
		return dist;
	}

	void Done(List<GameObject> ClosedSet, GameObject[] path){

		for (int i = 0; i < ClosedSet.Count; i++) {

			path [i] = ClosedSet [i];
		}

	}

	public static void LookAt2D(Transform transform, GameObject target)
	{
		Vector3 current = transform.position;
		var direction = target.transform.position - current;
		var angle = Mathf.Atan2(direction.y, direction.x)*Mathf.Rad2Deg + 270;
		transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
	}
}
*/