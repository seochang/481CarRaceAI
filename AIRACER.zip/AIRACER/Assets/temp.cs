﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class temp: MonoBehaviour {

	public GameObject[] beforepoint;
	public GameObject[] afterpoint; 
	public GameObject startNode;
	public GameObject goalNode;
	public GameObject checkPoint;
	List<GameObject> path1;
	List<GameObject> path2;
	GameObject[]path;
	int currentNode;
	int cb;
	int ca;
	public float speed;
	float dist;


	// Use this for initialization
	void Start () {
		currentNode = 0;
		cb = beforepoint.Length;
		ca = afterpoint.Length;

		path1 = new List<GameObject> ();
		path2 = new List<GameObject> ();

		FindPath (beforepoint, path1);
		GetPath (beforepoint, path2);

		List<GameObject> temp;
		temp = new List<GameObject> ();

		for(int i = 0; i < cb; i++){
			temp.Add (path1 [i]);
		}

		for(int k = 0; k < ca; k++){
			temp.Add (path2 [2]);
		}

		int count = temp.Count;
		path = new GameObject[count];

		for(int n = 0; n < count; n++) {
			path [n] = temp [n];
		}


	}

	// Update is called once per frame
	void Update () {
		if (transform.position != path [currentNode].transform.position) {
			Vector3 pos = Vector3.MoveTowards (transform.position, path[currentNode].transform.position, speed * Time.deltaTime);
			GetComponent<Rigidbody2D> ().MovePosition (pos);
			//transform.LookAt(path[currentNode].transform);
			LookAt2D (transform, path [currentNode]);
		} else
			currentNode = (currentNode + 1) % path.Length;
	}


	void FindPath(GameObject[] waypoints,List<GameObject>path){
		List<GameObject> OpenSet;
		List<GameObject> ClosedSet;

		GameObject parent = null;

		bool finished = false; 

		OpenSet = new List<GameObject>(waypoints);
		ClosedSet = new List<GameObject>();
		ClosedSet.Add (startNode);
		parent = startNode;

		if (parent == checkPoint) {
			finished = true;
		}
		while (finished == false) {
			if (parent == checkPoint) {
				finished = true;
			}
			if (OpenSet.Count < 2) {
				parent = checkPoint;
			}
			else if (f_cost (parent, OpenSet [0], checkPoint) > (f_cost (parent, OpenSet [1], checkPoint))) {
				parent = OpenSet [1];
			} else {
				parent = OpenSet [0];
			}
				ClosedSet.Add(parent);
				OpenSet.Remove(parent);
		}

		Done (ClosedSet, path);
	}


	void GetPath(GameObject[] waypoints,List<GameObject> path){
		List<GameObject> OpenSet;
		List<GameObject> ClosedSet;

		GameObject parent = null;

		bool finished = false; 

		OpenSet = new List<GameObject>(waypoints);
		ClosedSet = new List<GameObject>();
		ClosedSet.Add (startNode);
		parent = startNode;

		if (parent == checkPoint) {
			finished = true;
		}
		while (finished == false) {
			if (parent == checkPoint) {
				finished = true;
			}
			if(OpenSet.Count < 2){
				parent = checkPoint;

			}
			else if (f_cost (parent, OpenSet [0], goalNode) > (f_cost (parent, OpenSet [1], goalNode))) {
				parent = OpenSet [1];
			} else {
				parent = OpenSet [0];
			}
			ClosedSet.Add(parent);
			OpenSet.Remove(parent);
		}

		Done (ClosedSet, path);
	}
		
	float g_cost(GameObject curNode, GameObject nextNode){
		dist = Vector2.Distance (curNode.transform.position, nextNode.transform.position);
		return dist;
	}

	float h_cost(GameObject curNode, GameObject goalNode){
		dist = Vector2.Distance (curNode.transform.position, goalNode.transform.position);
		return dist;
	}

	float f_cost(GameObject curNode, GameObject nextNode, GameObject goalNode ){
		dist = g_cost (curNode, nextNode) + h_cost (nextNode, goalNode);
		return dist;
	}

	void Done(List<GameObject> ClosedSet,List<GameObject> path){

		int c = ClosedSet.Count;
		for (int i = 0; i < c; i++) {

			path.Add(ClosedSet [i]);
		}

	}

	public static void LookAt2D(Transform transform, GameObject target)
	{
		Vector3 current = transform.position;
		var direction = target.transform.position - current;
		var angle = Mathf.Atan2(direction.y, direction.x)*Mathf.Rad2Deg + 270;
		transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
	}
}
