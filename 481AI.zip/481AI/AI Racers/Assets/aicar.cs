﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class aicar : MonoBehaviour {

	public Transform startpoint;
	public Transform endpoint;

	private Transform tr; //save the AI_car's location
	private float navigationTime = 0.0f; //speed of the car
	private float navigationUpdate = 0.01f;


	// Use this for initialization
	void Start () {
		tr = GetComponent<Transform> ();

	}
	
	// Update is called once per frame
	void Update () {
		navigationTime += Time.deltaTime;
		//if(navigationTime > navigationUpdate){


	}
}
