﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pathfinding : MonoBehaviour {

	public Transform seeker, target;
	Grid grid;

	void Awake(){
		grid = GetComponent<Grid> ();
	}

	void Update(){

		FindPath (seeker.position, target.position);
	}

	// Use this for initialization
	void FindPath(Vector2 startPos, Vector2 targetPos){
		Node startNode = grid.NodeFromWorldPoint (startPos);
		Node targetNode = grid.NodeFromWorldPoint (targetPos);

		List<Node> openSet = new List<Node> (); //open to be evaluated
		HashSet<Node> closedSet = new HashSet<Node> (); //close that already evaluated
		openSet.Add (startNode);//add the start node to open

		while (openSet.Count>0){
			Node currentNode = openSet [0];
			for (int i = 1; i < openSet.Count; i++) {
				if (openSet [i].fCost < CurrentNode.fCost || openSet [i].fCost == currentNode.fCost && openSet[i].hCost < currentNode.hCost) {
					currentNode = openSet [i];
				} //current = node in OpenSet with the lowest fCost
			}
			openSet.Remove (currentNode);	//remove current from OpenSet
			closedSet.Add(currentNode);	//add current to ClosedSet

			if (currentNode == targetNode) {
				RetracePath (startNode, targetNode);
				return;
			}//if current is the target node, which mean path has been found, return


			foreach (Node neighbor in grid.GetNeighbors(currentNode)) { //foreach neighbors of the currentNode
				if (!neighbor.walkable || closedSet.Contains (neighbor)) { //if neighbors is not traversable or is in ClosedSet
					continue; //skip to the next neighbors
				}

				int newMovementCostToNeighbor = currentNode.gCost + GetDistance (currentNode, neighbor);
				if (newMovementCostToNeighbor < neighbor.gCost || !openSet.Contains (neighbor)) { //if new path to neighbors is shorter or is not in OpenSet
					neighbor.gCost = newMovementCostToNeighbor;
					neighbor.fCost = GetDistance (neighbor, targetNode); //set fCost of neighbor
					neighbor.parent = currentNode; //set parent of neighbor to current

					if (!openSet.Contains (neighbor)) 	//if neighbor is not in OpenSet, add neighbor to OpenSet
						openSet.Add (neighbor);	
				}
			}
		}
	}

	void RetracePath(Node startNode, Node endNode){
		List<Node> path = new List<Node> ();
		Node currentNode = endNode;

		while (currentNode != startNode) {
			path.Add (currentNode);
			currentNode = currentNode.parent;
		}

		path.Reverse ();
		grid.path = path;
	}


	int GetDistance (Node nodeA, Node nodeB){ //Getting distance btw two nodes)
		int dstX = Mathf.Abs (nodeA.gridX - nodeB.gridX);
		int dstY = Mathf.Abs (nodeA.gridY - nodeB.gridY);

		if (dstX > dstY)
			return 14 * dstY + 10 * (dstX - dstY);
		return 14 * dstX + 10 * (dstY - dstX);
	}






}
